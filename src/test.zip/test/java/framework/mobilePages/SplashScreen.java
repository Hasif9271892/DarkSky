package framework.mobilePages;

public class SplashScreen {
}
